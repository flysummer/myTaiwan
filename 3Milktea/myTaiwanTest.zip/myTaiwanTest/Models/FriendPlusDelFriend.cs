﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace myTaiwanTest.Models
{
    public class FriendPlusDelFriend
    {
        //for _ArctileLayout and myFriends //for _ArctileLayout and ArctileIndex
        public Sign sign { set; get; }
        public List<Sign> friendList { set; get; }
        public List<locations> locationInModel { set; get; }

    }
}